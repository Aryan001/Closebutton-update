    array = [];
    function Remove(event)
    {
        // console.log(event);
        console.log(event.currentTarget.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.attributes.id.value);
        //alert(event.currentTarget.parentNode.parentNode.attributes.id.value);
        array.push(event.currentTarget.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.attributes.id.value);
        var el = document.querySelector("#" + event.currentTarget.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.attributes.id.value);
        console.log(el);
        // el.style.visibility='hidden';
        angular.element(el).addClass('remove')
        // el.class = 'remove';
      // document.querySelector("#" + event.currentTarget.parentNode.parentNode.attributes.id.value).removeAttribute("hidden");
    }

    //var a=[0,0,0,0],i;
    var a = [];//, i;
    function Resize(event, i)
    {
        var optionsIndex = event.currentTarget.attributes.id.value;
        optionsIndex = optionsIndex.substr(6, optionsIndex.length - 6);
        var divId = 'div' + optionsIndex.toString();
        var divOuterId = 'divOuter' + optionsIndex.toString();

        var shrinkOrExpand = 0;
        //alert(a[i]);
        if (a[i] == 0)
        {
            a[i] = 1;
            shrinkOrExpand = 1;
            console.log(event.currentTarget.attributes.id.value);
            document.getElementById(event.currentTarget.attributes.id.value).className = "glyphicon glyphicon-resize-small";
            //document.getElementById(event.currentTarget.parentNode.parentNode.parentNode.parentNode.attributes.id.value).style.width = "1330px";
            document.getElementById(divOuterId).style.width="1300px";
            // document.getElementById(event.currentTarget.attributes.id.value).style.marginLeft="1000px";
            // document.getElementById(event.srcElement.parentElement.nextElementSibling.attributes.id.value).style.width = "1300px";
        }
        else
        {
            a[i] = 0;
            shrinkOrExpand = 0;
            document.getElementById(event.currentTarget.attributes.id.value).className = "glyphicon glyphicon-resize-full";
            //document.getElementById(event.currentTarget.parentNode.parentNode.parentNode.parentNode.attributes.id.value).style.width = "45%";
            document.getElementById(divOuterId).style.width = "600px";
            document.getElementById(event.currentTarget.attributes.id.value).style.marginLeft="100px";
            // document.getElementById(event.srcElement.parentElement.nextElementSibling.attributes.id.value).style.width = "550px";
        }
        //alert('optionsIndex is ' + optionsIndex);
        //alert('optionsIndex is ' + optionsIndex + ', shrinkOrExpand is ' + shrinkOrExpand);
        ResizeChart(optionsIndex, shrinkOrExpand);
    }


    function SetVisibility()
    {
        console.log("hai");

        var a = document.querySelectorAll(".draggable2");
        for (var k = 0; k < a.length; k++)
        {
            angular.element(a[k]).removeClass('remove')
            // console.log(a[k]);

            // console.log(a[k]);
            // a[k].class = 'remove';


        }
        // for (i = 0; i < array.length; i++)
        // {
        //     var el = document.querySelector("#" + array[i]);
        //     // angular.element(el).removeClass('remove')
        //     el.class = 'remove';
        // }
    }

    function Home()
    {
        array = [];
        var a = document.querySelectorAll(".draggable");
        console.log(a);
        //angular.element(a).removeClass('remove')
        a.class = '';
    }


    function Onegraph(event)
    {
        for (i = 0; i < event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children.length; i++)
        {
            var a = event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value;
            document.getElementById(a).style.width = "1330px";
            var b = event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value;
            document.getElementById(b).style.width = "1330px";
        }
    }

    function Twograph()
    {
        for (i = 0; i < event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children.length; i++)
        {
            var a = event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value;
            document.getElementById(a).style.width = "45%";
            var b = event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value;
            document.getElementById(b).style.width = "600px";
        }
    }

    function Threegraph()
    {
        for (i = 0; i < event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children.length; i++)
        {
            var a = event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value;
            document.getElementById(a).style.width = "30%";
            var b = event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value;
            document.getElementById(b).style.width = "380px";
        }
    }


    //divs = [];
    var j = -1;
    function AddDiv(inEntireRow)
    {
        j++;

        var divId = 'div' + j.toString();
        var resizeId = 'resize' + j.toString();
        var divOuterId = 'divOuter' + j.toString();
        console.log(j);
        console.log(divId);

        var innerHTML =       '<div class="draggable2" class="ui-widget-content" flex="50" id="' + divOuterId + '">';
        innerHTML=innerHTML + '<div layout="row" flex id="divhead">';
        //innerHTML=innerHTML + '<h3 flex="90">GRAPH ' + j + '.....</h3>';
        innerHTML = innerHTML + '<table width="100%;" border="0">';
        innerHTML = innerHTML + '<tr><td align="right" width="75%">';
        innerHTML=innerHTML + '<span flex="5" class="glyphicon glyphicon-resize-full"  id="'+resizeId+'" onclick="javascript:Resize(event, ' + j + ')">';
        innerHTML=innerHTML + '<md-tooltip md-direction="top">Fullscreen</md-tooltip>';
        innerHTML = innerHTML + '</span>';
        innerHTML = innerHTML + '</td><td align="middle" width="15%">';
        innerHTML=innerHTML + '<span flex="5" class="glyphicon glyphicon-remove-circle" id="close" onclick="javascript:Remove(event)">';
        innerHTML=innerHTML + '<md-tooltip md-direction="top">close</md-tooltip>';
        innerHTML = innerHTML + '</span>';
        innerHTML = innerHTML + '</td><td width="10%"></td></tr>';
        innerHTML = innerHTML + '<tr><td colspan="2">';
        innerHTML = innerHTML + '<div style="width:100%;position:relative;left:0px;" id="' + divId + '">';
        innerHTML = innerHTML + '</div>';
        innerHTML = innerHTML + '</td></tr></table>';
        innerHTML=innerHTML + '</div>';
        innerHTML=innerHTML + '</div>';

        var firstDiv = document.getElementById('FirstDiv');
        //alert(firstDiv.innerHTML);
        firstDiv.innerHTML = firstDiv.innerHTML + innerHTML;
        //alert(firstDiv.innerHTML);

        var divOuterId = 'divOuter' + j.toString();
        if (inEntireRow == 1)
        {
            document.getElementById(divOuterId).style.width = "1300px";
            document.getElementById(resizeId).style.visibility='hidden';
        }

        //j++;
        //divs.push(j);
        a.push(0);

        return divId;
    }

    function createButton()
    {
      // document.getElementById('forbutton').appendChild(button);
      var btn = document.createElement("BUTTON");
      var target = document.createTextNode("View");
      document.getElementById('forbutton').appendChild(btn);
      btn.appendChild(target);
      btn.onclick=SetVisibility;
    }

  $(function()
  {
    $('.dynamic').sortable();
    $( '.dynamic').disableSelection();
  })
